---
name: mfg-contract-reviewer
version: 1.0.0
description: Contract Review AI — Auto-extract key terms, identify risks, generate review opinions for manufacturing contracts
category: manufacturing
tags: [contract review, legal risk, procurement, sales, manufacturing, compliance]
priority: P2
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Contract Review AI (MFG Contract Reviewer)

> Upload a contract. AI extracts key terms, identifies risks, and generates review opinions with revision suggestions.

## Triggers

Activate when user mentions:
- "contract review", "contract risk", "contract terms"
- "purchase agreement", "sales contract", "manufacturing agreement"
- "payment terms", "delivery terms", "warranty", "liability"
- "contract template", "master service agreement"
- "legal review", "risk assessment"

## Core Positioning

An **AI contract review tool** for manufacturing. Upload procurement/sales/manufacturing contracts — AI extracts key clauses, identifies risks (payment traps, delivery imbalances, missing liabilities, intellectual property issues), and generates review opinions. Built-in manufacturing contract template library.

## Covered Contract Types

| Type | High-Risk Areas | Review Focus |
|------|----------------|--------------|
| Purchase Agreement | Harsh payment terms, vague quality standards | Payment %, acceptance criteria, penalty % |
| Sales Agreement | Collection risk, excessive warranty | Payment method, warranty period, force majeure |
| Manufacturing Agreement | Tolerance disputes, IP ownership | Technical standards, drawing ownership |
| Outsourcing Agreement | Delivery control, quality traceability | Delivery penalty, quality assurance |
| Equipment Purchase | Installation, training, after-sales response | Acceptance criteria, service terms |
| NDA | Overbroad scope, excessive penalties | Confidentiality period, penalty reasonableness |

## Workflows

### Workflow 1: Contract Upload & Analysis

```
Upload contract:
  ├── PDF
  ├── Word document
  ├── Photo (scanned)
  └── Paste text

    ↓

AI processing:
  ├── Contract structure recognition
  ├── Key clause extraction
  ├── Contract type classification
  └── Risk clause scanning
```

### Workflow 2: Risk Review

```
AI reviews:
├── Basic Info
│   ├── Party info completeness
│   ├── Date, validity period
│   └── Subject matter clarity
├── Price & Payment
│   ├── Total amount correctness
│   ├── Payment schedule reasonableness
│   └── Invoice & tax terms
├── Delivery
│   ├── Delivery time clarity
│   ├── Location & method
│   ├── Acceptance criteria & process
│   └── Late delivery liability
├── Quality & Warranty
│   ├── Standard references (ASTM/ISO/GB)
│   ├── Warranty period & scope
│   └── Quality dispute mechanism
├── Liability
│   ├── Penalty symmetry
│   ├── Termination conditions
│   └── Dispute resolution
└── Special Clauses
    ├── IP ownership
    ├── Confidentiality
    └── Force majeure
```

### Workflow 3: Review Report Generation

```
Output:
  ├── Contract summary (one-pager)
  ├── Risk list (by severity)
  ├── Clause-by-clause review
  ├── Revision suggestions
  └── Negotiation points
```

## Output Format

### Contract Review Report
```markdown
## Contract Review — Purchase Agreement

### Summary
| Item | Content |
|------|---------|
| Type | Purchase Agreement |
| Buyer | ABC Manufacturing |
| Supplier | XYZ Materials |
| Subject | 45# Steel Bar φ60, 10 tons |
| Amount | $38,900 |
| Payment | 30% prepay + 60% on delivery + 10% warranty |
| Delivery | June 15, 2026 |

### Risk Rating: 🟡 Medium (3 items to address)

#### 🔴 Critical (1)
**Risk 1: Warranty retention too high (20% in 24 months)**
- Industry standard: 5-10% retention, 6-12 months
- 20% × $38,900 = $7,780 tied up for 2 years
- **Suggestion**: Reduce to 10%, warranty 12 months

#### 🟡 Medium (2)
**Risk 2: Acceptance criteria vague**
- "Products shall meet relevant standards" — which ones?
- **Suggestion**: Specify "per ASTM A108 Grade 1018, carbon 0.15-0.20%, tensile ≥450MPa"

**Risk 3: Late delivery penalty too low**
- 0.1%/day = only $39/day — weak deterrent
- Supplier may choose to pay penalty vs expedite
- **Suggestion**: Increase to 0.3%/day, cap 15%

### Clause-by-Clause Review
| Clause | Grade | Suggestion |
|--------|-------|------------|
| Subject Matter | ✅ Clear | No change |
| Price & Payment | ✅ Acceptable | 30% prepay acceptable |
| Delivery | ✅ Clear | Add partial delivery schedule |
| Quality | ⚠️ Vague | Specify standard numbers |
| Acceptance | ⚠️ Incomplete | Add rejection period |
| Warranty | ❌ Unfavorable | Lower retention and period |
| Penalty | ⚠️ Weak | Increase rate |
| Confidentiality | ✅ OK | No change |
| Dispute | ⚠️ Biased | Change arbitration location |
```

## Manufacturing Contract Knowledge Base

### Risk Clause Reference

| Risk Type | Typical Clause | Risk | Review Point |
|-----------|---------------|------|--------------|
| Payment Trap | Prepay >50% | Credit risk | Prepay ≤30% |
| Delivery Imbalance | Heavy buyer penalty, light supplier penalty | Unfair | Penalty symmetry |
| Warranty Overreach | >24 mo + >15% retention | Capital tie-up | 6-12 mo, <10% |
| Vague Specs | "Meets applicable standards" | Unenforceable | Specific standard codes |
| Exclusive Deal | "No 3rd party procurement" | Supply chain lock | Evaluate impact |
| Biased Venue | Supplier's home court | Higher dispute cost | Neutral venue |
| IP Trap | "All improvements belong to buyer" | IP loss | Clarify ownership |
| Auto-renewal | "Auto-renew for 1 year" | Lose flexibility | Remove or opt-in |

### Industry Reference

| Clause | Industry Range | Suggested |
|--------|---------------|-----------|
| Prepayment | 20-30% | ≤30% |
| Warranty Retention | 5-10% | ≤10% |
| Warranty Period | 6-12 months | ≤12 months |
| Late Penalty | 0.1-0.5%/day | 0.3%/day |
| Penalty Cap | 10-20% | 15% |
| Acceptance Period | 7-15 business days | 10 days |
| Dispute Venue | Buyer/seller/neutral | Neutral |

## Usage Examples

### Example 1: New Contract Review
> User: "(uploads purchase agreement PDF)"
>
> AI: Review complete!
>
> 🔴 **Critical**: 20% warranty retention for 24 months (industry: 5-10%, 6-12 mo)
> 🟡 **Medium**: Vague specs, low penalty
>
> Priority negotiation: warranty terms. If rejected, consider alternative supplier.

### Example 2: Template Generation
> User: "I need a manufacturing agreement template (as the manufacturer)"
>
> AI: Generated (favorable to manufacturer):
> - Customer-supplied material quality responsibility
> - Reasonable tolerance clauses
> - IP: drawings belong to customer, process belongs to manufacturer
> - Acceptance: 10 business days, silent = acceptance
> - Force majeure includes raw material price fluctuations

### Example 3: Expiry Reminder
> User: "Check contracts expiring this month"
>
> AI: Contracts expiring:
> 
> | Contract | Party | Expires | Amount | Action |
> |----------|-------|---------|--------|--------|
> | Steel Supply | XYZ | 5/30 | $38K | Evaluate renew |
> | Outsourcing | ABC | 6/15 | $21K/mo | Begin review |
> | Equipment Maint | DEF | 7/01 | $5K/yr | Not yet |

## Limitations

1. AI provides suggestions, not legal advice. Consult attorney for significant contracts.
2. AI analyzes text only — cannot assess business context or negotiation dynamics.
3. Regulations update continuously — verify relevance periodically.
4. Industry practices vary — adjust for your sector.
5. Contract content is commercially sensitive — keep local.

## Competitive Comparison

| Dimension | This Skill | Lawyer Review | Legal AI Platforms |
|-----------|-----------|--------------|-------------------|
| Speed | 10 min | 1-3 days | 30 min |
| Manufacturing Expertise | High (built-in KB) | Varies | Medium (general) |
| Review Cost | ~$200 | $300-$1,500/review | $70-$280/review |
| Availability | 24/7 | Business hours | 24/7 |
| Templates | Manufacturing-specific | Limited | General |
| Legal Effect | Advisory | Legally binding | Advisory |
