---
name: mfg-equipment-guardian
version: 1.0.0
description: Equipment Health Predictor — Monitor equipment data, predict failures, recommend maintenance with low-cost IoT
category: manufacturing
tags: [equipment maintenance, predictive maintenance, failure prediction, TPM, manufacturing]
priority: P1
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Equipment Health Predictor (MFG Equipment Guardian)

> Monitor equipment data, predict failures before they happen, and schedule maintenance proactively.

## Triggers

Activate when user mentions:
- "equipment maintenance", "machine maintenance", "equipment management"
- "failure prediction", "predictive maintenance", "machine monitoring"
- "equipment health", "machine breakdown"
- "spare parts", "equipment log", "TPM"
- "machine repair", "equipment inspection"

## Core Positioning

An **AI equipment health management tool** for manufacturing. Analyzes machine data (vibration, temperature, current) to predict failures 7-14 days in advance, recommend maintenance actions and spare parts.

**Two modes**:
1. **Data-driven mode**: IoT sensor monitoring (recommended)
2. **Experience mode**: Based on manually recorded failure history

## Equipment Coverage

| Equipment Type | Monitored Parameters | Common Failures |
|---------------|---------------------|----------------|
| CNC Machine | Spindle vibration, current, temp | Bearing wear, ball screw play |
| Injection Molder | Barrel temp, hydraulic pressure | Heater failure, hydraulic leak |
| Press/Stamping | Slide vibration, motor current | Die wear, linkage play |
| Air Compressor | Exhaust temp, current, vibration | Bearing wear, valve failure |
| Welding Equipment | Current, voltage, temp | Welding tip wear |
| Pump/Fan | Vibration, flow, current | Seal leakage, impeller wear |

## Workflows

### Workflow 1: Equipment Profile Setup

```
Equipment info:
  ├── Basic (name, model, year, manufacturer)
  ├── Technical parameters
  ├── Critical wear parts (bearing #, seal #)
  ├── Historical failures (if any)
  └── Maintenance schedule (if any)

AI establishes baseline health profile
```

### Workflow 2: Monitoring & Alerts

```
Data collection (multiple methods):
  ├── IoT sensors (recommended)
  ├── Manual inspection input
  ├── Machine PLC data export
  └── Operating logs

    ↓

AI real-time analysis:
  ├── Trend analysis
  ├── Anomaly detection
  ├── Degradation recognition
  └── RUL estimation

    ↓

Status output:
  ├── 🟢 Normal
  ├── 🟡 Watch (monitor closely)
  ├── 🟠 Warning (plan maintenance)
  └── 🔴 Critical (immediate action needed)
```

### Workflow 3: Maintenance Recommendations

```
When alert triggers:
    ↓
AI generates maintenance plan:
  ├── Predicted failure type and time window
  ├── Recommended action
  ├── Spare parts needed
  ├── Estimated downtime
  ├── Cost estimate
  └── Risk of not maintaining
```

## Output Format

### Equipment Health Report
```markdown
## Equipment Health Report — May 2026

### Overview
| Machine | Health Score | Status | Predicted Issue | Suggested By |
|---------|-------------|--------|----------------|--------------|
| CNC-01 | 72/100 | 🟠 | Spindle bearing wear | 2 weeks |
| CNC-02 | 95/100 | 🟢 | — | Scheduled |
| Press-01 | 60/100 | 🟠 | Flywheel bearing | 1 week |

### CNC-01 Detailed Analysis

**Health Score**: 72/100 (down from 82 last month ⚠️)

**Trend**:
| Parameter | Last Month | This Month | Change | Status |
|-----------|-----------|------------|--------|--------|
| Vibration | 1.8 mm/s | 2.6 mm/s | ↑44% | 🟠 |
| Temp | 38°C | 42°C | ↑11% | 🟡 |
| Current | 11.2A | 12.5A | ↑12% | 🟡 |

**AI Diagnosis**:
- **Predicted**: Spindle bearing inner race wear (87% confidence)
- **Estimated failure**: 10-14 days
- **Recommendation**: Replace front bearing (model 7210AC)
- **Estimated downtime**: 4-6 hours
- **Cost**: ~$280 ($170 parts + $110 labor)
- **Risk of NOT maintaining**: Spindle damage ~$2,100 + 3 days downtime
```

### Monthly Equipment Report
```markdown
## May Equipment Management Report

### Key Metrics
| Metric | This Month | Last Month | Target | Trend |
|--------|-----------|------------|--------|-------|
| OEE | 78% | 75% | ≥80% | ↑ |
| Unplanned Stops | 3 | 5 | ≤2 | ↑ |
| Downtime | 18 hrs | 32 hrs | ≤10 hrs | ↑ |
| Maint Cost | $1,180 | $1,670 | — | ↓ |

### Preventive Maintenance Impact
This month, AI alerts prevented 2 potential breakdowns:
1. CNC-01: 10-day warning, planned maint cost $280 vs potential $2,100
2. Press-01: 7-day warning, planned maint cost $210 vs potential $2,800
**Total loss avoided: ~$4,400**
```

## Low-Cost IoT Solution

| Equipment | Sensor | Price | Installation |
|-----------|--------|-------|--------------|
| Rotating (CNC/pump) | Vibration sensor | $28 | Magnetic mount |
| Heating (molder/furnace) | Temp sensor | $7 | Thread mount |
| Electrical | Current transformer | $21 | Clip-on |
| Gateway | Data collection | $70 | DIN rail |
| **Total per machine** | **3-4 sensors + gateway** | **~$140** | — |

## Usage Examples

### Example 1: Quick Start (Experience Mode)
> User: "We don't have sensors. Can we still use this?"
>
> AI: Yes! Use experience mode:
> 1. Record 2 min daily status check (noise, temp, oil level)
> 2. Log failures with symptoms and fixes
> 3. AI analyzes patterns to identify high-risk machines
>
> Accuracy ~70% vs 85-90% with sensors. Upgrade later.

### Example 2: Failure Diagnosis
> User: "CNC-01 surface finish suddenly got worse"
>
> AI: Possible causes:
> | Rank | Cause | Probability | Check |
> | 1 | Tool wear | 60% | Inspect cutting edge |
> | 2 | Spindle bearing play | 25% | Vibration trending up ⚠️ |
> | 3 | Material hardness | 10% | Check incoming material |
>
> Given vibration increase (1.8→2.6 mm/s), recommend checking spindle ASAP

## Competitive Comparison

| Dimension | This Skill | Reactive Maintenance | Professional PdM |
|-----------|-----------|-------------------|-----------------|
| Failure Detection | 7-14 days ahead | After failure | 14-30 days ahead |
| Unplanned Stops ↓ | 60% | 0% | 80% |
| Maint Cost ↓ | 30% | 0% | 40% |
| Hardware/Machine | $140 | $0 | $700-$2,800 |
| Deployment | Low | None | High |
