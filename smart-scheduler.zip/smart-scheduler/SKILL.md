---
name: mfg-smart-scheduler
version: 1.0.0
description: Smart Production Scheduler — AI-powered production scheduling in minutes, replace Excel-based manual scheduling
category: manufacturing
tags: [scheduling, production planning, APS, manufacturing, Gantt chart]
priority: P0
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Smart Production Scheduler (MFG Smart Scheduler)

> AI-powered production scheduling in minutes. Say goodbye to Excel-based manual scheduling.

## Triggers

Activate when user mentions:
- "production scheduling", "production plan", "scheduling"
- "capacity planning", "rush order", "expedite"
- "equipment utilization", "due date", "capacity analysis"
- "Gantt chart", "shop floor scheduling", "line balancing"

## Core Positioning

An **AI scheduling assistant** for make-to-order and high-mix low-volume manufacturers. Replaces manual Excel scheduling — compress 6 hours of work into 30 minutes. Responds to rush orders in minutes. Outputs executable Gantt charts and detailed schedules.

## Applicable Scenarios

| Scenario | Pain Point | AI Value |
|----------|-----------|----------|
| High-mix low-volume | 100+ SKUs, 300+ orders/month | Intelligent sequencing reduces changeovers |
| Frequent rush orders | 1-3 urgent orders daily | Minutes-level rescheduling |
| Bottleneck equipment | Key machines overutilized | Multi-objective optimization |
| Tight delivery dates | Customer expediting, OTIF low | Automatic due date balancing |
| Multi-shop coordination | Cross-shop material flow | End-to-end routing optimization |

## Workflows

### Workflow 1: Initial Setup

```
Collect baseline data:
  ├── Shop info (name, stations, shifts)
  ├── Equipment info (name, model, capability, status)
  ├── Personnel (name, skills, shifts)
  └── Product routing (product→operations→cycle time→equipment)
```

### Workflow 2: Generate Schedule

```
Input:
  ├── Order list (order#, product, qty, due date, priority)
  ├── Current WIP status
  ├── Material availability
  └── Special constraints (maintenance, absences)

    ↓

AI Scheduling Engine:
  ├── Constraint modeling
  ├── Algorithm optimization (heuristic + metaheuristic)
  └── Multi-objective optimization

    ↓

Output schedule:
  ├── Gantt chart
  ├── Detailed schedule table
  ├── Risk alerts
  └── Key metrics (utilization, OTIF estimate)
```

### Workflow 3: Rush Order Rescheduling

```
User: Rush order! Product X, 100 pcs, due tomorrow!
    ↓
AI evaluates impact:
  ├── Which machines are affected
  ├── Impacted orders + delay estimates
  └── Alternative options (overtime, resequence, outsourcing)

    ↓

3 proposed plans:
  Plan A: Resequence, delay 2 low-priority orders
  Plan B: Overtime, no delays (cost increase)
  Plan C: Partial outsourcing

    ↓
User selects → AI updates schedule → Notify stations
```

### Workflow 4: Daily Review

```
End of shift:
  ├── AI compares plan vs actual execution
  ├── Identifies deviations (machine failures, late materials)
  ├── Generates next day adjustment recommendations
  └── Outputs daily capacity metrics report
```

## Input Format

### Order Input (JSON)
```json
{
  "orders": [
    {"order_id": "PO-001", "product": "Steering Knuckle A-200",
     "quantity": 500, "due_date": "2026-05-28", "priority": "high"}
  ]
}
```

### Natural Language Constraints
```
Constraints:
1. Machine A only available on day shift (8:00-17:00)
2. Zhang San on leave this week
3. Machine #3 under maintenance Wednesday
4. Products A-200 and A-300 cannot run simultaneously (tooling conflict)
```

### Excel Upload Supported
- Orders.xlsx, Equipment.xlsx, Personnel.xlsx

## Output Format

### Gantt Chart (Text View)
```
Station    | Mon 5/23        | Tue 5/24        | Wed 5/25
-----------|-----------------|-----------------|-----------------
CNC-01     | [PO-001 Knuckle] | [PO-001]        | [PO-003 Gear]
CNC-02     | [PO-002 Bearing] | [PO-003 Gear]   | [PO-004 Bearing]
```

### Schedule Detail Table
```markdown
## Schedule — May 23-28

### Key Metrics
| Metric | Value | Target | Status |
|--------|-------|--------|--------|
| Machine Utilization | 82% | ≥80% | ✅ |
| OTIF Estimate | 95% | ≥95% | ✅ |
| Changeovers | 8 | ≤12 | ✅ |

### Schedule Detail
| Order | Product | Qty | Start | End | Due | Status |
|-------|---------|-----|-------|-----|-----|--------|
| PO-001 | Knuckle A-200 | 500 | 5/23 08:00 | 5/25 17:00 | 5/28 | ✅ |

### Risk Alerts
| Risk | Impact | Suggestion |
|------|--------|------------|
| 45# steel stock sufficient for PO-001 only | PO-003 may be short | Order now |
```

## Scheduling Algorithm

### Core Constraints
| Type | Description | Example |
|------|-------------|---------|
| Equipment | One task per machine at a time | CNC-01 can only run one job |
| Sequence | Operation dependencies | Rough→Finish→Heat treat |
| Personnel | Operator skill + shift limits | Zhang San operates CNC-01 only |
| Material | Material available to start | Cannot schedule without stock |
| Due Date | Must finish before due date | PO-001 due 5/28 |
| Equipment Compatibility | Product matches machine | Product A needs CNC-01 only |

### Optimization Objectives
1. Minimize lateness
2. Maximize equipment utilization
3. Minimize changeovers
4. Minimize WIP wait time

## Usage Examples

### Example 1: Daily Scheduling
> User: "Schedule this week's 5 orders"
>
> AI: Please provide order list and current equipment status.
>
> User: "(uploads Excel + CNC-02 maintenance tomorrow)"
>
> AI: Schedule generated!
> - All 5 orders on time
> - Avg utilization: 81%
> - CNC-02 maintenance avoided
> - Changeovers: 6 (vs 12 manually)
>
> ⚠️ Risk: PO-003 material low — order today

### Example 2: Rush Order
> User: "Rush order! 100 bearings, due day after tomorrow!"
>
> AI: Analyzing impact...
>
> Options:
> | Plan | Action | Impact | Cost |
> | A | Delay PO-005 | 1 day delay | $0 |
> | B | Overtime 4hrs | No delay | $110 |
> | C | Outsource 50 pcs | No delay | $280 |
>
> Recommend Plan B.

### Example 3: Natural Language Constraints
> User: "Li on leave Wednesday, heat treat only has Wang. Customer says PO-002 can delay 1 day."
>
> AI: Constraints updated. Rescheduling...
>
> Heat treat moved to Tuesday. PO-002 relaxation frees CNC-02 for rush order. New utilization: 84%

## Limitations

1. Standard times are estimates; 10-20% deviation is normal. Keep 10% buffer.
2. AI plans need human review before execution.
3. Accuracy depends on input data quality.
4. Supports ≤50 machines, ≤200 concurrent orders.
5. Run daily plan-vs-actual review.

## Competitive Comparison

| Dimension | This Skill | Excel | MES | APS |
|-----------|-----------|-------|-----|-----|
| Time to Schedule | 30 min | 4-6 hrs | 1-2 hrs | 30 min |
| Constraints Handled | 100+ | <10 | 20-50 | 100+ |
| Rush Order Response | Minutes | Half day | 1-2 hrs | Minutes |
| Machine Utilization | 75-85% | 55-65% | 65-75% | 75-85% |
| Cost | ~$200 | $0 | $15K-40K | $70K-$280K |
