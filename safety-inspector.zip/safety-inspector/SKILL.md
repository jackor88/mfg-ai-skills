---
name: mfg-safety-inspector
version: 1.0.0
description: Safety Inspection AI — Photo-based hazard detection + compliance document management for workplace safety
category: manufacturing
tags: [safety inspection, hazard detection, compliance, manufacturing, EHS]
priority: P1
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Safety Inspection AI (MFG Safety Inspector)

> Snap photos during safety rounds. AI automatically identifies hazards, generates corrective work orders, and tracks closure.

## Triggers

Activate when user mentions:
- "safety inspection", "safety check", "hazard detection"
- "workplace safety", "safety compliance"
- "fire inspection", "PPE", "safety equipment"
- "safety incident", "safety training", "emergency plan"

## Core Positioning

An **AI-powered safety inspection tool** for manufacturing. Replaces paper-based safety checklists. Inspectors use their phone to take photos — AI identifies hazards in real-time, generates corrective work orders, and tracks them to closure. Built-in regulatory knowledge base.

## Inspection Coverage

### 8 Key Areas

| # | Area | Check Points | AI Detection |
|---|------|-------------|-------------|
| 1 | Machine Safety | Guards, emergency stop, interlocks | Missing guards, exposed rotating parts |
| 2 | Electrical Safety | Panels, wiring, grounding | Open panels, exposed wires |
| 3 | Fire Safety | Extinguishers, hydrants, exits | Expired extinguishers, blocked exits |
| 4 | Hazardous Materials | Storage, labeling, MSDS | Improper storage, missing labels |
| 5 | Work Environment | Lighting, ventilation, housekeeping | Wet floors, overstacked materials |
| 6 | PPE | Hard hats, safety glasses, gloves | Missing hard hat, no safety shoes |
| 7 | Working at Height | Scaffolding, harnesses | No harness, missing guardrails |
| 8 | Special Equipment | Forklifts, cranes, pressure vessels | Forklift misuse |

## Workflows

### Workflow 1: Inspection Round Creation

```
AI generates inspection plan:
  ├── Daily (must-check items)
  ├── Weekly (focused inspections)
  ├── Monthly (comprehensive)
  └── Special (pre-holiday, post-storm)

Includes:
  ├── Optimized route
  ├── Checklist per checkpoint
  └── Historical issues for follow-up
```

### Workflow 2: On-site Inspection (Mobile)

```
Inspector arrives at checkpoint
    ↓
Photo + voice description of findings
    ↓
AI real-time analysis:
  ├── Identifies hazard type and severity
  ├── References safety regulations
  └── Generates annotated hazard photo
    ↓
Inspection complete → Auto-generates report
```

### Workflow 3: Corrective Action Tracking

```
Hazard identified during inspection
    ↓
AI auto-generates work order:
  ├── Hazard description + photo
  ├── Severity level
  ├── Assigned responsible person
  ├── Due date
  └── Recommended corrective action
    ↓
Responsible party fixes → submits completion photo
    ↓
AI compares before/after → Verified → Order closed
```

### Workflow 4: Safety Data Analysis

```
Periodic analysis:
  ├── Hazard count trend
  ├── Hazard type distribution
  ├── Area heatmap
  ├── Closure rate
  ├── Repeat issue rate
  └── Industry incident alerts
```

## Output Format

### Inspection Report
```markdown
## Safety Inspection Report #SI-20260523

**Date**: 2026-05-23
**Inspector**: John Safety
**Area**: Workshop 1 + Warehouse + Office
**Type**: Weekly

### Overview
| Metric | Value |
|--------|-------|
| Checkpoints | 25 |
| Pass | 21 |
| Hazards Found | 4 |
| Corrected On-site | 2 |
| Requires Follow-up | 2 |

### Hazard List
| # | Description | Location | Severity | Status |
|---|-------------|----------|----------|--------|
| 1 | Panel door open | CNC area | Major | Corrected ✅ |
| 2 | Extinguisher expired | Warehouse | Major | Follow-up |
| 3 | Aisle blocked | Workshop 1 | Minor | Corrected ✅ |
| 4 | Worker no safety glasses | Grinding area | Minor | Follow-up |

### Corrective Work Orders
**WO-001**: Replace expired fire extinguisher
- Responsible: Mike Manager
- Due: 2026-05-25
- Reference: NFPA 10

### Weekly Safety Score
| Dimension | Score | Status |
|-----------|-------|--------|
| Machine Safety | 90/100 | ✅ |
| Electrical | 75/100 | ⚠️ |
| Fire Safety | 70/100 | ⚠️ |
| Housekeeping | 85/100 | ✅ |
| PPE | 80/100 | ⚠️ |
| **Overall** | **80/100** | ⚠️ |
```

## Hazard Knowledge Base

### Severity Classification (OSHA-based)

| Level | Criteria | Correction Due |
|-------|----------|---------------|
| **Imminent Danger** | Could cause death/serious injury | Immediate shutdown |
| **Serious** | Could cause injury | Within 24 hours |
| **Minor** | Non-compliant but low risk | Within 7 days |
| **Observation** | Best practice suggestion | Within 30 days |

### Common Hazard AI Detection Rules

| Hazard | Visual Feature | Severity |
|--------|---------------|----------|
| Missing hard hat | No yellow/red hat on head | Serious |
| Expired extinguisher | Date tag past expiration | Serious |
| Blocked aisle | Obstruction on walkway | Minor |
| Open electrical panel | Panel door open | Serious |
| Exposed wiring | Damaged insulation, copper visible | Imminent |
| Missing machine guard | Rotating part exposed | Imminent |
| Wet floor | Abnormal liquid reflection | Minor |
| Overstacked material | Height >2m / leaning | Minor |
| Missing guardrail | Platform edge unprotected | Imminent |

## Usage Examples

### Example 1: Daily Round
> User: "Start today's safety round"
>
> AI: Today's route (est. 30 min):
> 1. Workshop 1 entrance → Fire equipment
> 2. CNC area → Guards + panels
> 3. Grinding area → PPE + dust collection
> 4. Warehouse → Aisles + extinguishers
>
> Focus: Recheck panel issue from yesterday

### Example 2: Photo Detection
> User: "(uploads panel photo)"
>
> AI: Hazard detected!
>
> ❌ **Open electrical panel** (Severity: Major)
> - Risk: Electric shock, arc flash
> - Code ref: NFPA 70E
> - Correct immediately

### Example 3: Monthly Analysis
> User: "Generate May safety analysis"
>
> AI: 41 hazards found this month, 95% closure rate. 15% improvement from April.
>
> ⚠️ Watch items:
> - Grinding area PPE issues: 3 consecutive months #1
> - Fire extinguisher expiration recurring — set up calendar
> - Industry alert: electrical incidents rising — schedule plant-wide electrical inspection

## Competitive Comparison

| Dimension | This Skill | Paper Checklist | Professional EHS System |
|-----------|-----------|----------------|------------------------|
| Inspection | Phone photo + AI | Paper form | Mobile app |
| Hazard Detection | AI auto-detect | Manual | Manual input |
| Efficiency | 30 min | 60-90 min | 45 min |
| Correction Tracking | Auto closed-loop | Manual | System tracked |
| Data Analysis | AI trend analysis | None | Reports |
| Deployment Cost | <$500 | ~$0 | $7K-$28K |
