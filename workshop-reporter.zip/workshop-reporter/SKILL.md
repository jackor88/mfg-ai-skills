---
name: mfg-workshop-reporter
version: 1.0.0
description: Workshop Reporter — Multi-source data collection → auto-generate production dashboards and management reports
category: manufacturing
tags: [workshop report, production report, output tracking, capacity analysis, data reporting]
priority: P2
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Workshop Reporter (MFG Workshop Reporter)

> Collect data from multiple sources. AI auto-generates daily/weekly/monthly shop floor reports in minutes.

## Triggers

Activate when user mentions:
- "workshop report", "production report", "daily output"
- "production dashboard", "management report", "data report"
- "output summary", "labor hours", "defect rate", "yield analysis"
- "OTIF", "OEE", "equipment utilization"

## Core Positioning

Solves the **"shop floor black hole"** — workers fill paper forms, clerks compile reports manually, managers see outdated data. This skill collects data from multiple sources (MES/Excel/paper/voice), auto-generates standardized reports, and flags anomalies.

## Supported Report Types

| Report | Frequency | Key Metrics | Audience |
|--------|-----------|-------------|----------|
| Daily Production Report | Daily | Output, yield, hours, issues | Shift supervisor / PM |
| Weekly Production Report | Weekly | Weekly output, trends, target | PM / GM |
| Quality Report | Weekly | Defect rate, defect distribution | QA Manager / GM |
| Equipment Monthly Report | Monthly | OEE, downtime, maint cost | Equipment Manager / GM |
| Efficiency Monthly Report | Monthly | Output/head, capacity utilization | GM / Operations |

## Workflows

### Workflow 1: Data Collection (Multi-source)

```
Supported sources:
  ├── MES export (Excel/CSV)
  ├── ERP export (Excel/CSV)
  ├── Manual Excel records
  ├── Paper travel card photo (OCR)
  ├── Voice input ("Today production 200, good 195")
  └── Form input

    ↓

AI processing:
  ├── Format standardization
  ├── Data cleaning
  ├── Anomaly detection
  └── Cross-validation
```

### Workflow 2: Report Generation

```
From collected data → Auto-calculate metrics → Generate report
    ↓
Report includes:
  ├── KPI cards
  ├── Trend charts
  ├── Anomaly alerts (items off target)
  ├── Detail data (expandable)
  └── AI executive summary
```

### Workflow 3: Smart Analysis

```
AI auto-analysis:
  ├── Actual vs plan
  ├── Trend analysis
  ├── Bottleneck identification
  ├── Root cause hypothesis
  └── Action recommendations
```

## Output Format

### Daily Production Report
```markdown
## Production Daily Report — May 23, 2026

### Overview
| Metric | Value | Target | Achievement | Status |
|--------|-------|--------|-------------|--------|
| Total Output | 285 pcs | 300 pcs | 95% | ⚠️ |
| Yield Rate | 96.5% | ≥98% | — | ⚠️ |
| OEE | 76% | ≥80% | — | ⚠️ |

### By Line
| Line | Product | Plan | Actual | Good | Yield | Hours |
|------|---------|------|--------|------|-------|-------|
| Line 1 | Knuckle A-200 | 100 | 95 | 92 | 96.8% | 8h |
| Line 1 | Gear C-50 | 80 | 82 | 80 | 97.6% | 8h |
| Line 2 | Bearing B-100 | 120 | 108 | 105 | 97.2% | 8h |

### Abnormal Events
| Time | Line | Issue | Impact | Status |
|------|------|-------|--------|--------|
| 14:00 | Line 1 | CNC-01 tool break, 1hr downtime | -8 pcs | Resolved ✅ |

### AI Summary
> Output missed target (95%) due to:
> 1. CNC-01 tool break (1hr, 8 pcs lost)
> 2. Line 2 material 30 min late (5 pcs lost)
>
> Recommendations:
> - Implement tool life monitoring (today's break @480 pcs, avg life ~500)
> - Strengthen material follow-up (3rd late delivery this month)
```

## Usage Examples

### Example 1: Daily Entry
> User: "Record today's Line 1 production"
>
> AI: Please provide product, plan, actual, good, and any issues.
>
> User: "A-200 plan 100, actual 95, good 92. CNC-01 tool broke, 1 hour down."
>
> AI: Recorded. Summary:
> - Output: 177 (target 180, 98%)
> - Yield: 97.2%
> - Issue: CNC-01 tool break
>
> ⚠️ CNC-01 3rd break this month. Check cutting parameters?

### Example 2: Paper Digitization
> User: "(uploads 3 paper travel card photos)"
>
> AI: OCR complete. Data extracted:
> | Card | Product | Qty | Good | Operator | Date |
> | W-001 | A-200 | 48 | 47 | Zhang | 5/22 |
> | W-002 | A-200 | 50 | 49 | Zhang | 5/22 |
> | W-003 | C-50 | 40 | 39 | Li | 5/22 |
>
> ⚠️ W-001 qty "48" has low OCR confidence (72%), please confirm.

### Example 3: Monthly Report
> User: "Generate May management report for the boss"
>
> AI: May report generated:
>
> **Highlights**:
> - Output 8,500 units, +8% MoM
> - Yield 97.2% (from 95.5%)
> - OEE 78% (from 72%)
>
> **Issues**:
> - 5.6% below monthly target
> - Line 2 material availability 82%
>
> **June Plan**: ... (auto-generated)

## Limitations

1. Report quality depends on input data quality
2. OCR accuracy ~85-90% for paper records
3. Root cause analysis is statistical — requires field validation
4. Recommend entering data each shift, report generated next day
5. Production data is sensitive — keep local

## Competitive Comparison

| Dimension | This Skill | Paper Reports | MES Reports | BI Dashboard |
|-----------|-----------|-------------|-------------|--------------|
| Data Collection | Multi-source | Manual | Auto | DB-connected |
| Report Generation | 10 min | 2 hrs | Auto | Auto |
| Smart Analysis | AI | None | Limited | Needs config |
| Deployment Cost | <$500 | ~$0 | $15K-$70K | $7K-$42K |
| Entry Barrier | Low | Lowest | High | Medium |
