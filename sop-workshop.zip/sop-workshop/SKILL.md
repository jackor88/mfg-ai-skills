---
name: mfg-sop-workshop
version: 1.0.0
description: SOP Generator — Senior operators describe steps verbally, AI auto-generates standard operating procedures
category: manufacturing
tags: [SOP, standard operating procedure, work instructions, training, knowledge retention]
priority: P1
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# SOP Generator (MFG SOP Workshop)

> Senior operator describes steps verbally. AI generates standard operating procedures in 30 minutes — saving 3 days of manual work.

## Triggers

Activate when user mentions:
- "SOP", "standard operating procedure", "work instruction"
- "process sheet", "operating procedure"
- "quality control point", "critical process", "process parameter"
- "operator training", "new employee training"

## Core Positioning

Solves the **knowledge retention crisis** in manufacturing. Senior operators describe their process verbally — AI generates structured SOP documents with step-by-step breakdowns, quality standards, safety notes, and visual aids. Supports version management and multilingual export.

## Applicable Scenarios

| Scenario | Pain Point | AI Value |
|----------|-----------|----------|
| New product SOP | Engineer too busy, writing takes days | 30 min first draft |
| Retiring expert retention | Knowledge walks out the door | Auto-documentation |
| New hire training | Outdated training materials | Real operation-based SOP |
| Process change updates | SOP not updated after changes | Rapid revision |
| Multilingual SOP | Foreign clients need English | One-click translation |
| Quality audit prep | ISO/IATF audit needs complete SOPs | Compliant format | 

## Workflows

### Workflow 1: Voice-to-SOP

```
Method A: Voice Recording (recommended)
  Record step-by-step narration
  "Step 1, place the blank in the fixture..."
  "Step 2, start the CNC, feed at 200mm/min..."

Method B: Text Description
  Direct text input

Method C: Video Recording
  Record process video, AI extracts steps

Method D: Legacy Import
  Upload old SOP or process sheet

    ↓

AI Processing:
  ├── Speech-to-text (ASR)
  ├── Step-by-step decomposition
  ├── Auto-add quality standards + safety notes
  ├── Step illustration suggestions
  └── Generate standard SOP

    ↓

User review → Approve & publish
```

### Workflow 2: Version Management

```
SOP version history:
  V1.0 → V1.1 (parameter adjustment)
  Change note: Step 3 feed rate from 200 to 180
  Reason: Customer surface roughness requirement
  Approval: Process supervisor

Old versions archived, diff comparison supported
```

### Workflow 3: Training Material Generation

```
Based on SOP generate:
  ├── Training cards (for shop floor posting)
  ├── Quiz questions (auto-generated from SOP)
  ├── Video script (for filming)
  └── Quick reference cards
```

## Output Format

### Standard SOP Document
```markdown
# Standard Operating Procedure

## Basic Info
| Item | Content |
|------|---------|
| SOP # | SOP-MFG-001 |
| Product | Steering Knuckle A-200 |
| Operation | CNC Finish Machining |
| Equipment | CNC-VMC850 |
| Version | V1.0 |

## Scope
- Equipment: CNC-VMC850 series
- Product: Knuckle A-200/A-210/A-220
- Conditions: 15-35°C, humidity ≤80%

## Tools & Materials
| Category | Item | Spec | Qty |
|----------|------|------|-----|
| Tool | Hex wrench | M8 | 1 |
| Tool | Caliper | 0-150mm | 1 |
| Material | Blank | A-200 | 1/piece |

## Pre-Operation Checks
- [ ] Check machine status (spindle, coolant, lube)
- [ ] Verify fixture secure and locating surfaces clean
- [ ] PPE: safety glasses, safety shoes

## Operation Steps

### Step 1: Load Part
**Operation**: Place blank in fixture, align locating surface to fixture datum
**Key Points**:
  - Clean locating surface, no burrs
  - Gently place, avoid impact
  - Confirm full contact with datum
**Std Time**: 30 sec
**Quality**: Positioning deviation ≤0.05mm

### Step 2: Clamp
**Operation**: Tighten 4 M8 bolts in diagonal sequence
**Key Points**:
  - Diagonal tightening for even force
  - Torque: 15N·m
  - Check for looseness after tightening
**Std Time**: 45 sec
**Safety**: Keep fingers away from clamp area

### Step 3: Start Machining
**Operation**: Press green start button
**Key Points**:
  - Verify program number (O1001)
  - Step back to safe zone
  - Monitor first piece fully
**Std Time**: 8 min (auto)
**Parameters**: Spindle 3000rpm, Feed 200mm/min

### Step 4: Quality Check
**Operation**: Remove part, measure per inspection standard
**Quality Standards**:
| Check Item | Standard | Tolerance | Tool |
|-----------|----------|-----------|------|
| Diameter | φ50 | ±0.02mm | Caliper |
| Length | 120 | ±0.05mm | Caliper | 
| Roughness | Ra1.6 | ≤Ra1.6 | Comparator |

## Safety Notes
1. Never reach into machining area during operation
2. Stop spindle/coolant before changing tools
3. Emergency stop for abnormal noise
4. Clean chips and coolant at end of shift
```

## Usage Examples

### Example 1: Voice-to-SOP
> User: "I'll describe the injection molding process"
>
> (Voice input) "Step 1, check the hopper for material, set temp to 220°C..."
>
> AI: SOP draft generated! Includes:
> - 5 steps (setup→heat→inject→open→inspect)
> - Quality standards per step
> - Safety notes (burns, pinch points)
> - Process parameters table
>
> Please confirm: product name and cycle time?

### Example 2: Legacy Document Upgrade
> User: "(uploads handwritten process card photo)"
>
> AI: Handwriting recognized. New SOP generated with:
> - All 12 steps extracted
> - Safety notes added (missing in original)
> - Standard times estimated
> - Anomaly handling guide
>
> ⚠️ 2 unclear values need confirmation

## Competitive Comparison

| Dimension | This Skill | Manual Writing | Professional SOP SW |
|-----------|-----------|---------------|-------------------|
| Time to Write | 30 min | 1-3 days | 2-4 hours |
| Entry Barrier | Voice only | Computer skills | Training needed |
| Quality | AI draft + human review | Person-dependent | Template-based |
| Knowledge Retention | Auto-documented | Word of mouth | Manual entry |
| Multilingual | One-click | Manual translation | Partial |
| Version Control | Built-in | Folder management | Professional |
| Cost | ~$500 | Labor cost | $4K-$15K |
