---
name: mfg-energy-analyst
version: 1.0.0
description: Energy Cost Analyst — Upload electricity bills, AI analyzes usage patterns and generates energy-saving plans
category: manufacturing
tags: [energy analysis, electricity, cost reduction, energy saving, manufacturing]
priority: P1
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Energy Cost Analyst (MFG Energy Analyst)

> Upload electricity bills. AI analyzes consumption patterns, identifies waste, and generates energy-saving plans with ROI.

## Triggers

Activate when user mentions:
- "energy analysis", "electricity bill", "power consumption"
- "energy saving", "cost reduction", "energy optimization"
- "peak/off-peak usage", "power factor"
- "energy waste", "idle consumption"

## Core Positioning

An **AI energy analysis tool** for manufacturing. Analyzes utility bills to identify waste, benchmark against industry standards, and generate customized energy-saving plans with investment ROI. Works with just your electricity bill — no IoT hardware required.

## Applicable Industries

| Industry | Key Energy Feature | Analysis Focus |
|----------|-------------------|----------------|
| Injection Molding | High cyclic load | Idle consumption, peak shifting |
| Metal Stamping | High instantaneous power | Demand management |
| Heat Treatment | Continuous high consumption | Insulation optimization |
| CNC Machining | Multiple machines running | Utilization vs energy |
| Die Casting | Furnace + machine | Furnace idle time |
| Air Compressors | Plant-wide "electricity hog" | Leak detection, VFD retrofit |

## Workflows

### Workflow 1: Bill Analysis (Quick Start)

```
Upload electricity bill (photo/PDF/Excel)
    ↓
AI auto-extracts key data:
  ├── Consumption (peak/flat/off-peak)
  ├── Total cost and breakdown
  ├── Power factor
  ├── Maximum demand
  └── Power factor adjustment fee
    ↓
Generate energy analysis report
```

### Workflow 2: Energy Diagnosis

```
Input: 12 months of bills
    ↓
Multi-dimensional analysis:
  ├── Consumption trend (YoY/MoM)
  ├── Peak/off-peak ratio
  ├── Power factor analysis
  ├── Energy per unit of output
  ├── Monthly fluctuation
  └── Seasonal pattern recognition
    ↓
Output: Diagnosis report + anomaly list
```

### Workflow 3: Energy-Saving Plan

```
Based on diagnosis + industry knowledge base
    ↓
AI generates customized plan:
  ├── No-cost measures (management optimization)
  ├── Low-cost (<$1K, quick payback)
  ├── Medium investment ($1K-$15K, 1-2 year payback)
  └── High investment (>$15K, long-term)
    ↓
Each measure includes:
  ├── Specific action
  ├── Expected savings (kWh/yr)
  ├── Cost savings ($/yr)
  ├── Investment amount
  ├── Payback period
  └── Implementation difficulty
```

## Output Format

### Energy Analysis Report
```markdown
## Energy Report — ABC Manufacturing

**Period**: Jun 2025 - May 2026
**Annual Consumption**: 1,250,000 kWh
**Annual Cost**: $145,800

### Overview
| Metric | Value | Benchmark | Status |
|--------|-------|-----------|--------|
| Energy/Output | 850 kWh/$10K | 700 kWh/$10K | ⚠️ |
| Peak Ratio | 65:35 | 40:60 | ⚠️ |
| Power Factor | 0.82 | ≥0.90 | ❌ |

### Issues Found
| # | Issue | Severity | Annual Loss |
|---|-------|----------|-------------|
| 1 | High peak consumption | High | $11,700 |
| 2 | Low power factor | High | $5,300 |
| 3 | Summer spike (A/C) | Medium | $3,500 |

### Energy-Saving Plan

#### No-Cost (Immediate)
| # | Action | Savings/yr | Difficulty |
|---|--------|------------|------------|
| 1 | Shift production to night shift | $5,800 | Easy |
| 2 | Equipment shutdown after hours | $2,100 | Easy |
| 3 | Adjust A/C temperature | $1,700 | Easy |
| **Subtotal** | | **$9,600** | |

#### Low-Cost (<$1K)
| # | Action | Investment | Savings/yr | Payback |
|---|--------|------------|------------|---------|
| 1 | Install power factor correction | $1,100 | $5,300 | 2.5 mo |
| 2 | Compressed air leak repair | $420 | $2,500 | 2 mo |
| **Subtotal** | | **$1,520** | **$7,800** | |

#### Medium Investment
| # | Action | Investment | Savings/yr | Payback |
|---|--------|------------|------------|---------|
| 1 | Air compressor VFD retrofit | $4,900 | $5,800 | 10 mo |

### Summary
| Package | Investment | Annual Savings | Payback |
|---------|------------|---------------|---------|
| No-Cost | $0 | $9,600 | Immediate |
| + Low-Cost | $1,520 | $17,400 | 1 month |
| All | $6,420 | $23,200 | 3.3 mo |
```

## Usage Examples

### Example 1: Quick Analysis
> User: "(uploads 3 months of bills)"
>
> AI: Analysis complete. Key findings:
>
> **Issue 1: High peak consumption (68%)**
> - Peak rate $0.13/kWh, off-peak $0.05
> - Shifting 30% to off-peak saves ~$11K/yr
>
> **Issue 2: Power factor 0.81 ($480/mo penalty)**
> - Power factor correction: ~$1,100, 2.5 month payback
>
> Generate full plan?

## Industry Benchmarks

| Industry | Energy/Output (kWh/$10K) | Air Compressor % | Lighting/A/C % |
|----------|-------------------------|-----------------|---------------|
| Machining | 600-800 | 25-35% | 8-12% |
| Injection Molding | 1000-1500 | 20-30% | 5-8% |
| Stamping | 400-600 | 20-25% | 8-10% |
| Heat Treatment | 2000-3000 | 15-20% | 5-8% |
| Electronics | 300-500 | 30-40% | 15-20% |

## Competitive Comparison

| Dimension | This Skill | Professional EMS | Utility Energy Service |
|-----------|-----------|-----------------|----------------------|
| Entry Barrier | Upload bill only | IoT hardware req | Passive wait |
| Granularity | Monthly/device | Real-time/second | Monthly |
| Cost | ~$200 | $15K-$70K | Free |
| Customization | AI auto-adapt | Needs configuration | Generic |
| Energy Plan | Auto-generated | Expert required | Simple suggestions |
