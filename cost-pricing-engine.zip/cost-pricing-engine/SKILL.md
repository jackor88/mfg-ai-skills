---
name: mfg-cost-pricing-engine
version: 1.0.0
description: Cost & Pricing Engine — Auto-collect cost data from BOM, routing, and labor to generate instant pricing proposals
category: manufacturing
tags: [costing, pricing, BOM, production cost, profit analysis, manufacturing]
priority: P1
author: Product Strategy Team
created: 2026-05-23
agent_created: true
---

# Cost & Pricing Engine (MFG Cost & Pricing Engine)

> Input BOM and routing data. AI calculates full costs and generates multi-tier pricing proposals in minutes.

## Triggers

Activate when user mentions:
- "cost estimation", "product pricing", "quotation"
- "BOM cost", "material cost", "processing cost"
- "profit calculation", "margin analysis", "cost analysis"
- "labor cost", "manufacturing cost", "overhead allocation"

## Core Positioning

Solves the **"takes too long to quote, costs are always off"** problem. Input BOM + routing + batch size — AI auto-collects material, labor, machine, and overhead costs. Generates multi-tier pricing at different margins. Flags cost anomalies automatically.

## Cost Model

### 5 Cost Dimensions
```
Total Cost = Material + Processing + Labor + Manufacturing Overhead + Admin Overhead

Material = Σ(material qty × unit price) × (1 + scrap rate)
Processing = Σ(operation time × machine hour rate) + tooling amortization
Labor = Σ(operation time × labor rate)
Manufacturing OH = (utilities + depreciation + facility) × allocation rate
Admin OH = labor × admin overhead rate
```

### Pricing Matrix
| Tier | Margin | Positioning | Use Case |
|------|--------|-------------|----------|
| Break-even | 5% | Floor price | Strategic must-win |
| Standard | 15% | Normal quote | Regular customers |
| Premium | 25% | Premium price | Rush/special orders |
| Strategic | 30%+ | High margin | Exclusive/custom work |

## Workflows

### Workflow 1: Cost Collection

```
Input (Excel/manual/drawing AI):
  ├── BOM (bill of materials)
  ├── Routing (operations + equipment + time)
  ├── Material prices
  ├── Rate parameters (machine/labor rates)
  └── Order info (qty, due date, special req)

    ↓

AI auto-calculates:
  ├── Material cost detail
  ├── Processing cost detail
  ├── Labor cost detail
  ├── OH allocation
  └── Cost structure analysis
```

### Workflow 2: Quote Generation

```
Input: cost data + target margin
    ↓

AI generates quote:
  ├── Cost breakdown
  ├── Multi-margin comparison
  ├── Quantity discount ladder
  ├── Payment terms suggestion
  └── Formal quote (PDF/Excel export)
```

### Workflow 3: Cost Anomaly Alerts

```
AI continuously monitors:
  ├── Material price fluctuation >10%
  ├── Cost structure anomaly
  ├── Margin risk (actual vs quoted)
  └── Competitor price deviation
```

## Output Format

### Cost Breakdown
```markdown
## Cost Report — Steering Knuckle A-200

### Cost Detail

#### 1. Material Cost
| Item | Spec | Qty | Unit Price | Scrap | Subtotal |
|------|------|-----|-----------|-------|----------|
| 45# Steel Bar | φ60×120mm | 1 | $3.90 | 5% | $4.10 |
| Bolt M8 | M8×25 | 4 | $0.04 | 0% | $0.16 |
| **Material Subtotal** | | | | | **$4.26** |

#### 2. Processing Cost
| Op | Machine | Time | Rate | Subtotal |
|----|---------|------|------|----------|
| Cut-off | Saw | 5min | $0.07/min | $0.35 |
| Rough Turn | CNC | 15min | $0.21/min | $3.15 |
| Finish Turn | CNC | 20min | $0.21/min | $4.20 |
| Mill Keyway | CNC | 10min | $0.21/min | $2.10 |
| Heat Treat | Outsource | — | — | $2.50 |
| Grind | Grinder | 15min | $0.17/min | $2.55 |
| **Processing Subtotal** | | | | **$14.85** |

#### 3. Labor Cost
| Op | Time | Rate | Subtotal |
|----|------|------|----------|
| Cut-off | 5min | $0.11/min | $0.55 |
| CNC | 45min | $0.14/min | $6.30 |
| Grind | 15min | $0.14/min | $2.10 |
| Inspection | 5min | $0.11/min | $0.55 |
| **Labor Subtotal** | | | **$9.50** |

#### 4. Overhead
| Item | Allocation | Amount |
|------|-----------|--------|
| Machine Depreciation | $0.28/machine hr | $0.53 |
| Utilities | $0.14/machine hr | $0.27 |
| Facility | $0.07/machine hr | $0.14 |
| **OH Subtotal** | | **$0.94** |

#### 5. Admin Overhead (15% of labor+processing)
| Item | Amount |
|------|--------|
| Admin OH | **$3.65** |

### Summary
| Cost Item | Per Unit | % |
|-----------|---------|---|
| Material | $4.26 | 13% |
| Processing | $14.85 | 45% |
| Labor | $9.50 | 29% |
| Mfg OH | $0.94 | 3% |
| Admin OH | $3.65 | 11% |
| **Total Unit Cost** | **$33.20** | — |
| Tooling Amortization (500 pcs) | $2.80/pc | — |
| **With Tooling** | **$36.00/pc** | — |

### Pricing Tiers
| Tier | Margin | Unit Price | 500 pcs Total |
|------|--------|-----------|---------------|
| Break-even | 5% | $37.80 | $18,900 |
| Standard | 15% | $41.40 | $20,700 |
| Premium | 25% | $45.00 | $22,500 |
| Strategic | 30% | $46.80 | $23,400 |
```

## Usage Examples

### Example 1: Quick Quote
> User: "Customer needs 500 pcs steering knuckle quote. BOM and routing attached."
>
> AI: Cost calculated!
> - Unit cost: $36.00 (incl tooling amortization)
> - Recommended: $41.40 (15% margin)
> - 500 pcs total: $20,700
>
> ⚠️ Note: Heat treat supplier increased price 22%

### Example 2: Competitor Analysis
> User: "Competitor quoted $34. Can we match?"
>
> AI: Analysis:
> - Our cost: $36.00
> - Competitor: $34
> - Breakeven: $37.80
>
> At $34, we lose $2.00/pc. However, via material substitution, we can reduce cost by ~$2.10/pc → $33.90, making $34 profitable at 0.3% margin. Recommend accepting at $34.50 for 1.8% margin.

### Example 3: Volume Pricing
> User: "Quote for 100/500/1000/5000 pcs"
>
> AI: Volume pricing:
> | Qty | Unit Cost | Tooling/Pc | 15% Margin Price | Total |
> |-----|-----------|-----------|-----------------|-------|
> | 100 | $36.00 | $14.00 | $57.50 | $5,750 |
> | 500 | $36.00 | $2.80 | $44.60 | $22,300 |
> | 1000 | $35.20 | $1.40 | $42.10 | $42,100 |
> | 5000 | $34.50 | $0.28 | $40.00 | $200,000 |

## Limitations

1. Pricing accuracy depends on input data quality (material prices, cycle times)
2. Tooling amortization should reflect expected tool life
3. Outsourcing prices fluctuate — maintain multiple supplier rates
4. Default excludes tax, shipping, and quality costs
5. Quote info is commercially sensitive — ensure data security

## Competitive Comparison

| Dimension | This Skill | Manual Excel | ERP Module | Professional Quoting |
|-----------|-----------|-------------|-----------|-------------------|
| Speed | 5-10 min | 2-4 hrs | 30 min | 15 min |
| Accuracy | High (multi-dimension) | Medium | High | High |
| Multi-tier Auto | Auto | Manual | Limited | Supported |
| Cost Reduction Sugg. | AI | None | None | Limited |
| Anomaly Alerts | Auto | None | Partial | Partial |
| Cost | ~$500 | $0 | ERP cost | $7K-$28K |
